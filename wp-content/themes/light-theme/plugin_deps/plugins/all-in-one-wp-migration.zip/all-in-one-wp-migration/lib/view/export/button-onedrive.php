<a href="https://servmask.com/products/onedrive-extension" target="_blank"><?php _e( 'OneDrive', AI1WM_PLUGIN_NAME ); ?></a>
